class Piece
  
  def initialize(color, board, pos)
    @color = color
    @board = board
    @pos = pos
  end


end