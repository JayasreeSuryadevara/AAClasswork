module.exports = {
    mongoURI: 'mongodb+srv://admin:2GEcCrgp4pACvX9D@cluster0-t3qdi.mongodb.net/test?retryWrites=true&w=majority',
    secretOrKey: 'secretsecret'
};