module.exports = [
    require('./User'),
    require('./Category'),
    require('./Product'),
    require('./Order')
]
